create extension if not exists pgcrypto;
create table if not exists public.profiles(id uuid primary key references auth.users(id) on delete cascade,is_admin boolean not null default false);
create table if not exists public.files(id uuid primary key default gen_random_uuid(),name text not null,path text not null,url text not null,kind text not null check(kind in('ppt','music')),created_at timestamptz not null default now());
alter table public.profiles enable row level security; alter table public.files enable row level security;
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$select exists(select 1 from public.profiles where id=auth.uid() and is_admin=true)$$;
create policy "public read files" on public.files for select using(true);
create policy "admin insert files" on public.files for insert with check(public.is_admin());
create policy "admin delete files" on public.files for delete using(public.is_admin());
create policy "own profile" on public.profiles for select using(id=auth.uid());
insert into storage.buckets(id,name,public) values('presentations','presentations',true) on conflict(id) do update set public=true;
insert into storage.buckets(id,name,public) values('music','music',true) on conflict(id) do update set public=true;
create policy "public view ppt" on storage.objects for select using(bucket_id='presentations');
create policy "admin upload ppt" on storage.objects for insert with check(bucket_id='presentations' and public.is_admin());
create policy "admin delete ppt" on storage.objects for delete using(bucket_id='presentations' and public.is_admin());
create policy "public view music" on storage.objects for select using(bucket_id='music');
create policy "admin upload music" on storage.objects for insert with check(bucket_id='music' and public.is_admin());
create policy "admin delete music" on storage.objects for delete using(bucket_id='music' and public.is_admin());
-- After creating your Auth user, run:
-- insert into public.profiles(id,is_admin) values('YOUR-AUTH-USER-UUID',true) on conflict(id) do update set is_admin=true;
