# MY FILE SPACE

Website online kho PPT: giao diện trắng/xám modern, animation mở trang, chuyển PPT bằng ← →, download, Admin-only upload/delete, music player.

## Cài online
1. Tạo project Supabase.
2. Authentication > Users: tạo tài khoản Admin email/password.
3. SQL Editor: chạy toàn bộ `sql/setup.sql`.
4. Lấy UUID của user Admin và chạy INSERT ở cuối file SQL để cấp quyền.
5. Vào `js/config.js`, dán Project URL và anon/publishable key.
6. Đưa cả thư mục lên GitHub, rồi deploy bằng Netlify/Vercel.

Không đưa service_role/secret key vào frontend.

Lưu ý: trình duyệt có thể chặn autoplay nhạc cho tới khi người xem tương tác lần đầu.
