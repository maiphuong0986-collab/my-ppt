// Paste your Supabase Project URL and browser-safe anon/publishable key here.
// NEVER put a service_role/secret key in frontend code.
window.SUPABASE_URL="PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
window.SUPABASE_ANON_KEY="PASTE_YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY_HERE";
